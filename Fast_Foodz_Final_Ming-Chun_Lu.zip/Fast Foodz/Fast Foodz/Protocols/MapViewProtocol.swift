//
//  mapViewProtocol.swift
//  Fast Foodz
//
//  Created by Jeff on 2021/8/6.
//

import Foundation

protocol MapViewProtocol {
    func setupPins()
}
