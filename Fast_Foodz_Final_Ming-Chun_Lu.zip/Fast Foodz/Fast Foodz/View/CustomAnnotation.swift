//
//  CustomAnnotation.swift
//  Fast Foodz
//
//  Created by Jeff on 2021/8/6.
//


import MapKit

class CustomAnnotation: MKPointAnnotation {
    var pinCustomImageName:String!
    var place: Place!
}
