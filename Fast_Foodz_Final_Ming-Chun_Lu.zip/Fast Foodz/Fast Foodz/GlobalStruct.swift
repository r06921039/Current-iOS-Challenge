//
//  APIKey.swift
//  Fast Foodz
//

struct Constants {
    static let yelpAPIKey = "EM4gJp1gsCjaU0JF0dZY6EI0c3JfcBV51ZzJzfGjX3gqs0D9VN0VGD5-mmCE4Gnasz-AzR8oiZNAcsZ4dHo87m0LEMbbzUsa3LdYpHI24RFIDhxKjHR6A8X4GaksXnYx"
    static let API_URL = "https://api.yelp.com/v3/businesses/search"
}

