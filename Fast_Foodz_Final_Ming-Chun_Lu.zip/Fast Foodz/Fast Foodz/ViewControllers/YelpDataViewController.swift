//
//  YelpDataViewController.swift
//  Fast Foodz
//
//  Created by Jeff on 2021/8/6.
//

import Foundation
import UIKit

class YelpDataViewController: UIViewController{
    public var places: [Place] = []
    public var delegate: HomeViewController!
}
